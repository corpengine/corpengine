CORP Engine is a game engine/toolkit made in Python using the Pygame library.

Benefits of using CORP Engine

- It can really make your python game development experience more organized, faster, and better in general.
- It has **built-in parent-children system** with **game objects** and **services** to use. 
- It is very simple and efficient to work with compared to Pygame.
- Also, the entire engine code is in a **single file**, making it _really_ easy to set up.

Learning CORP Engine

There is no wiki for now, but you can check https://github.com/corpengine/examples/
for some examples to start with.
